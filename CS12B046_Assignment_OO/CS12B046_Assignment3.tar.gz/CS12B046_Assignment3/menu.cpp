/*********************************************************
 * Auther : PANKAJ YADAV
 * Email : pp55018@gmail.com
 * Roll No : CS12B046
 *********************************************************/

#include<iostream>
#include<string.h>

#define AVAILABLE 1
#define NOT_AVAILABLE 0
#define MAX_ITEMS 100

#define PIZZA 1
#define CAKE 2
#define COLDCOFFEE 3

#define UNDEFINED -1
#define TOTAL_CATAGORIES 3

using namespace std;

class Menu{
	public:
		int* catagorie;
		int* sub_catagorie;
		int* price;
		int* time_taken;
		void init_items(int* catagorie , int* sub_catagorie , int* price , int* time_taken);
		void add_item(int* catagorie , int* sub_catagorie , int* price , int* time_taken , 
					int cat , int sub_cat, int price_ , int time);
		void delete_item(int* catagorie , int* sub_catagorie ,int* price ,
      					int* time_taken , int cat , int sub_cat );
      		void print_menu(int* catagorie , int* sub_catagorie , int* price);
};
/*
 * This function initilize all items and mark as undefined
 * @param catagorie : catagorie of food
 * @param sub_catagorie : sub catagorie of food
 * @param price : price of items
 * @param time_taken : time taken to make this item
 * @return nothing
 */

void Menu::init_items(int* catagorie , int* sub_catagorie , int* price , int* time_taken)
{
	int i;
	
	for(i = 0 ; i< MAX_ITEMS ; i++)
	{
		catagorie[i] = UNDEFINED;
		sub_catagorie[i] = UNDEFINED;
		price[i] = UNDEFINED;
		time_taken[i] = UNDEFINED;
	}
	cout<<"CAME HERE"<<endl;
}

/*
 * This function is used for adding items into menu
 * @param cat : catagorie of food
 * @param sub_cat : sub catagorie of food
 * @param price_ : price of items
 * @param time : time taken to make this item
 * @return nothing
 */

void Menu::add_item(int* catagorie , int* sub_catagorie , int* price , int* time_taken , 
      int cat , int sub_cat, int price_ , int time){
      int i;
      for(i = 0 ; i < MAX_ITEMS ; i++)
      {
      		if(catagorie[i] == UNDEFINED)
      		{
      			catagorie[i] = cat;
			sub_catagorie[i] = sub_cat;
			price[i] = price_;
			time_taken[i] = time;
			return;
      		}
      }
}

/*
 * This function is used for deleting item from menu
 * @param cat : catagorie of food
 * @param sub_cat : sub catagorie of food
 * @param price : price of items
 * @param time_taken : time taken to make this item
 * @return nothing
 */

void Menu::delete_item(int* catagorie , int* sub_catagorie ,int* price ,
      int* time_taken , int cat , int sub_cat ){
	int i;
	for(i = 0 ; i < MAX_ITEMS ; i++)
	{
		if(catagorie[i] == cat && sub_catagorie[i] == sub_cat)
		{
			catagorie[i] = UNDEFINED;
			sub_catagorie[i] = -999999;
			price[i] = UNDEFINED;
			time_taken[i] = UNDEFINED;
		}
	}
}

/*
 * This function is used for printing menu
 * @param catagorie : catagorie of food
 * @param sub_catagorie : sub catagorie of food
 * @param price : price of items
 * @return nothing
 */

void Menu::print_menu(int* catagorie , int* sub_catagorie , int* price)
{
	int i,j;
	char sub[4];
	for(i = 1 ; i <= TOTAL_CATAGORIES ; i++)
	{
		if(i == PIZZA)
		{
			printf("PIZZAS:\n");
		}
		if(i == CAKE)
		{
			printf("CAKES:\n");
		}
		if(i == COLDCOFFEE)
		{
			printf("COLD COFFEES:\n");
		}
		
		for(j = 0 ; j < MAX_ITEMS ; j++)
		{
			if(sub_catagorie[j] == 1111)
				strcpy(sub,"XXXX");
			if(sub_catagorie[j] == 2222)
				strcpy(sub,"YYYY");
			if(sub_catagorie[j] == 3333)
				strcpy(sub,"ZZZZ");
			if(sub_catagorie[j] == 4444)
				strcpy(sub,"AAAA");
			if(sub_catagorie[j] == 5555)
				strcpy(sub,"BBBB");
			if(sub_catagorie[j] == 6666)
				strcpy(sub,"CCCC");
			if(sub_catagorie[j] == 7777)
				strcpy(sub,"DDDD");
			if(sub_catagorie[j] == 8888)
				strcpy(sub,"EEEE");
			if(sub_catagorie[j] == 9999)
				strcpy(sub,"FFFF");
	
			if(catagorie[j] == i)
			{
				printf("%s\t%d\n",sub,price[j]);
			}	
		}
	}
}




















