/*********************************************************
 * Auther : PANKAJ YADAV
 * Email : pp55018@gmail.com
 * Roll No : CS12B046
 *********************************************************/
 
#include<iostream>

/*
 * this function will print cafe in differt type.
 * @param : nothing
 * @return : nothing
 */

using namespace std;

class Home{
	public:
		void print_cafe_home();
};

void Home::print_cafe_home()
{
	printf("=========================\n");
	printf( "####  #### #### ####\n"
		"#     #  # #    #\n"
		"#     #### #### ####\n"
		"#     #  # #    #\n"
		"####  #  # #    ####\n");
	printf("=========================\n");
}
