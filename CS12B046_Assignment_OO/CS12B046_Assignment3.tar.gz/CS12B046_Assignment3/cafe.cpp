/*********************************************************
 * Auther : PANKAJ YADAV
 * Email : pp55018@gmail.com
 * Roll No : CS12B046
 *********************************************************/

#include <iostream>
#include <malloc.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h> 

#include "menu.cpp"
#include "employee.cpp"
#include "simulate.cpp"
#include "print_home.cpp"
#include "table.cpp"

using namespace std;

void simulate();

/*
 * Just main function nothing much just calls simulate function
 */
 
int main()
{
	simulate();
	return 0;
}

/*
 * This function generally simulate cafe and find attendence of 
 * their employees and start working.
 * @param employees : array of employees is they present or not.
 * @param catagorie : catagories of food
 * @param sub_catagorie : sub catagorie of food.
 * @param price : price of some items
 * @param tables: which table is allocated or which are free
 * @param time_taken : time taken to make some item
 * @param i : use for iterate for loop
 * @return nothing
 */

void simulate()
{
	Employees e;
	Home home;
	Menu menu;
	Table table;
	Simulate simulate;
	int i;
	int rand_employee = rand()%MAX_EMPLOYEES;
	e.employees = (int *)malloc(MAX_EMPLOYEES*sizeof(int));
	menu.catagorie = (int *) malloc(MAX_ITEMS*sizeof(int));
	menu.sub_catagorie = (int*) malloc(MAX_ITEMS*sizeof(int));
	menu.price = (int*) malloc(MAX_ITEMS*sizeof(int));
	menu.time_taken = (int *) malloc(MAX_ITEMS*sizeof(int));
	table.tables = (int *) malloc(MAX_TABLES*sizeof(int));
	
	menu.init_items(menu.catagorie ,menu.sub_catagorie,menu.price ,menu.time_taken);
	
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,PIZZA,1111,230,15);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,PIZZA,2222,120,12);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,PIZZA,3333,340,11);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,CAKE,4444,300,9);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,CAKE,5555,170,5);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,CAKE,6666,390,4);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,COLDCOFFEE,7777,528,22);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,COLDCOFFEE,8888,143,17);
	menu.add_item(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken,COLDCOFFEE,9999,347,23);
	
	e.employees = e.init_employee(e.employees);
	table.tables = table.init_tables(table.tables);
	home.print_cafe_home();
	sleep(2);
	e.mark_absent(e.employees,rand_employee);
	printf("============ATTENDENCE============\n");
	e.print_all_employees_status(e.employees);
	printf("==================================\n");
	sleep(1);
	printf("Total %d are present\n",e.total_employees(e.employees));
	sleep(1);
	printf("Lets start working..\n");
	sleep(1);
	menu.print_menu(menu.catagorie ,menu.sub_catagorie,menu.price);
	simulate.simulate_ordering(menu.catagorie ,menu.sub_catagorie,menu.price,menu.time_taken);
}




















